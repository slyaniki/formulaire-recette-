<?php

    class database{
        static private $host="localhost";
        static private $user = "root";
        static private $password="";
        static private $db = "bara";
        static private $connexion = null;

        static public function connexion(){
            self::$connexion = new PDO("mysql:host=".self::$host.";dbname=".self::$db.";",self::$user,self::$password);
            return self::$connexion;            
        }

        static public function deconnexion(){
            self::$connexion = null;            
        }
    }
    
    function insertMember($data,$datas){
        $db = $data;
        $qprepare = $db->prepare("INSERT INTO clients(nom,prenoms,activite,civilite,date_naiss,commune,telephone,email,region,message) VALUES(?,?,?,?,?,?,?,?,?,?)");
        $qex = $qprepare->execute($datas);
        return $qex;
    }

    
    function checkInput($data){
        $dts = htmlentities($data);
        return htmlspecialchars($dts);
    }
?>