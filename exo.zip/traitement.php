<?php 
    include "database.php";

    $db = database::connexion();

    $erArray = ["erNum"=>"","erNom"=>"","erPrenom"=>"","erActivi"=>"","erDate"=>"","erCivil"=>"","erRegion"=>"","erCommune"=>"","erEmail"=>""];

    var_dump($_POST);
    if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST)){
        $isValidate = true;
        $nom = checkInput($_POST["nom"]);
        $prenom = checkInput($_POST["prenom"]);
        $activi = isset($_POST["activite"])?checkInput($_POST["activite"]):"";
        $tel = checkInput($_POST["tel"]);
        $dateNaiss = checkInput($_POST["date_naiss"]);
        $region = checkInput($_POST["region"]);
        $commune = checkInput($_POST["commune"]);
        $email = checkInput($_POST["email"]);
        $message = checkInput($_POST["msg"]);
        $civil = checkInput($_POST["civil"]);
        


        if(empty($nom)){
           $erArray["erNom"] = "Veuillez indiquer votre Nom";
           $isValidate = false;
        }

        if(empty($prenom)){
           $erArray["erPrenom"] = "Veuillez indiquer votre prenom";
           $isValidate = false;
        }

        if(empty($activi)){
           $erArray["erActivi"] = "Veuillez indiquer votre activité";
           $isValidate = false;
        }

        if(empty($dateNaiss)){
           $erArray["erDate"] = "Veuillez indiquer votre date de naissance";
           $isValidate = false;
        }

        if(empty($civil)){
           $erArray["erCivil"] = "Veuillez indiquer votre civilité";
           $isValidate = false;
        }

        if(empty($region)){
           $erArray["erRegion"] = "Veuillez indiquer votre region";
           $isValidate = false;
        }

        if(empty($commune)){
           $erArray["erCommune"] = "Veuillez indiquer votre Commune";
           $isValidate = false;
        }

        if(empty($email) && !filter_var($email,FILTER_VALIDATE_EMAIL)){
           $erArray["erEmail"] = "Veuillez saisir votre mail";
           $isValidate = false;
        }

        
        if($isValidate){
            $ok = insertMember($db,[$nom,$prenom,$activi,$civil,$dateNaiss,$commune,$tel,$email,$region,$message]);
            
            if($ok){
                echo "Votre inscription a effectuée avec succèss";
                sleep(10);
                header("location: index.php");
            }else{
                echo "Votre inscription a echouée veuillez ressayer";
            }   
        }else{
            var_dump($erArray);
        }    
    }
?>