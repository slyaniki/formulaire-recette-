
<?php include("header.php") ?>
<div id="form">
    <form action="traitement.php" method="post">
        <label for="nom">Nom : </label>
        <input type="text" name="nom" id="nom">
        <label for="prenom">Prenom</label>
        <input type="text" name="prenom" id="prenom">
        <label for="activi">Activité</label>
        <input type="text" name="activite" id="activi">
        <label for="date">Date de naissance </label>
        <input type="date" name="date_naiss" id="date">
        <label for="region">Region</label>
        <select name="region" id="region">
            <option value="district d'Abidjan">District d'Abidjan</option>
            <option value="Gontougo">Gontogo</option>
            <option value="Lagunes">Lacs</option>
            <option value="Yopougnon">Bas-Sassandra</option>
            <option value="Comoé">Comoé</option>
        </select>
        <label for="commune">Commune</label>
        <select name="commune" id="commune">
            <option value="koumassi">Koumassi</option>
            <option value="Marcory">Marcory</option>
            <option value="Adjame">Adjame</option>
            <option value="Yopougnon">Yopougnon</option>
            <option value="Cocody">Cocody</option>
        </select>
        <label for="mail">Email</label>
        <input type="email" name="email" id="mail">
        <label for="tel">telephone</label>
        <input type="text" name="tel" id="tel">
        <label for="civil">Civilité</label>
        <input type="text" name="civil" id="civil">
        <label for="msg">Message</label>
        <textarea name="msg" id="msg" cols="30" rows="10"></textarea><br>
        <button>Valider</button>
    </form>
</div>
</body>

</html>